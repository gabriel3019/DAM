package Ejercicios;

public class Ej2 {
	public int Roscas;
	public int resistencias;
	public int cristales;

	public Ej2(int roscas, int resistencias, int cristales) {
		this.Roscas = roscas;
		this.resistencias = resistencias;
		this.cristales = cristales;
	}

	public void construirBombilla(int cantidad, int ingresos, int gastos) {
			int precio = 0;
			
		

	}
	
	public void aumentarCantidad(int cantidad, int unidades) {
		
	}
	
	public void elaborarBombilla() {
		
	}
}
